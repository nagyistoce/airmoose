

#import "ToolbarController.h"
#import "MainController.h"

static NSString *AirStumblerToolbarIdentifier = @"AirStumblerToolbarIdentifier";
static NSString *AirStumblerToggleScan = @"AirStumblerToggleScan";
static NSString *AirStumblerJoinNetwork = @"AirStumblerJoinNetwork";
static NSString *AirStumblerDropNetwork = @"AirStumblerDropNetwork";
static NSString *AirStumblerOpenLog = @"AirStumblerOpenLog";
static NSString *AirStumblerSaveLog = @"AirStumblerSaveLog";
static NSString *AirStumblerShowLog = @"AirStumblerShowLog";
static NSString *AirStumblerClearLog = @"AirStumblerClearLog";
static NSString *AirStumblerPrefs = @"AirStumblerPrefs";
static NSString *AirStumblerStatus = @"AirStumblerStatus";


@implementation ToolbarController

-(void)awakeFromNib {
[self load];
}

-(void)load {
toolbar = [[NSToolbar alloc] initWithIdentifier:AirStumblerToolbarIdentifier];
[toolbar setAllowsUserCustomization:YES];
[toolbar setSizeMode:NSToolbarSizeModeDefault];
[toolbar setAutosavesConfiguration:NO];
[toolbar setDelegate:self];
[window setToolbar:toolbar];
}

-(NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdent willBeInsertedIntoToolbar:(BOOL)willBeInserted {

NSToolbarItem *toolbarItem = [[NSToolbarItem alloc] initWithItemIdentifier:itemIdent];
[toolbarItem autorelease];

    if ([itemIdent isEqual:AirStumblerToggleScan]) { 

        [toolbarItem setLabel: @"Scan"];
        [toolbarItem setPaletteLabel: @"Scan"];
        [toolbarItem setImage:[NSImage imageNamed: @"Toggle"]];
        [toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(toggleScanSelected:)];
	
	
	
	} else if ([itemIdent isEqual:AirStumblerJoinNetwork]) {

		[toolbarItem setLabel: @"Join"];
		[toolbarItem setPaletteLabel: @"Join"];
		[toolbarItem setImage:[NSImage imageNamed: @"Join"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(joinNetworkSelected:)];



	} else if ([itemIdent isEqual:AirStumblerDropNetwork]) {

		[toolbarItem setLabel: @"Drop"];
		[toolbarItem setPaletteLabel: @"Drop"];
		[toolbarItem setImage:[NSImage imageNamed: @"Drop"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(dropNetworkSelected:)];



	} else if ([itemIdent isEqual:AirStumblerOpenLog]) {

		[toolbarItem setLabel: @"Open"];
		[toolbarItem setPaletteLabel: @"Open"];
		[toolbarItem setImage:[NSImage imageNamed: @"Open"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(openLogSelected:)];


	} else if ([itemIdent isEqual:AirStumblerSaveLog]) {

		[toolbarItem setLabel: @"Save"];
		[toolbarItem setPaletteLabel: @"Save"];
		[toolbarItem setImage:[NSImage imageNamed: @"Save"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(saveLogSelected:)];



	} else if ([itemIdent isEqual:AirStumblerShowLog]) {

		[toolbarItem setLabel: @"Show Log"];
		[toolbarItem setPaletteLabel: @"Show Log"];
		[toolbarItem setImage:[NSImage imageNamed: @"Show"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(showLogSelected:)];



	} else if ([itemIdent isEqual:AirStumblerClearLog]) {

		[toolbarItem setLabel: @"Clear Log"];
		[toolbarItem setPaletteLabel: @"Clear Log"];
		[toolbarItem setImage:[NSImage imageNamed: @"Clean"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(clearLogSelected:)];



	} else if ([itemIdent isEqual:AirStumblerPrefs]) {

		[toolbarItem setLabel: @"Prefs"];
		[toolbarItem setPaletteLabel: @"Prefs"];
		[toolbarItem setImage:[NSImage imageNamed: @"Pref"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(prefsSelected:)];



	} else if ([itemIdent isEqual:AirStumblerStatus]) {

		[toolbarItem setLabel: @"AP Stat"];
		[toolbarItem setPaletteLabel: @"AP Stat"];
		[toolbarItem setImage:[NSImage imageNamed: @"Stat"]];
		[toolbarItem setTarget:mainControl];
		[toolbarItem setAction:@selector(curConnStatSelected:)];

} else {
return nil;
}

return toolbarItem;



}


-(NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar *)toolbar {

return [NSArray arrayWithObjects: NSToolbarFlexibleSpaceItemIdentifier,
								  AirStumblerToggleScan,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerJoinNetwork,
								  AirStumblerDropNetwork,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerOpenLog,
								  AirStumblerSaveLog,
								  AirStumblerShowLog,
								  AirStumblerClearLog,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerPrefs,
								  AirStumblerStatus,
								  NSToolbarFlexibleSpaceItemIdentifier, nil];
}

-(NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar *)toolbar {

return [NSArray arrayWithObjects: NSToolbarFlexibleSpaceItemIdentifier,
								  AirStumblerToggleScan,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerJoinNetwork,
								  AirStumblerDropNetwork,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerOpenLog,
								  AirStumblerSaveLog,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerShowLog,
								  AirStumblerClearLog,
								  NSToolbarSeparatorItemIdentifier,
								  AirStumblerPrefs,
								  AirStumblerStatus, 
								  NSToolbarFlexibleSpaceItemIdentifier, nil];
}

@end
